function enviar(){

  
    opSexo="";
  nome = document.getElementById("txtNome").value;
  idade = document.getElementById("txtIdade").value;
  idade = parseInt(idade);
  sexo = document.getElementsByName("sexo");
  if(sexo[0].checked){
    opSexo="Masculino";
  }if(sexo[1].checked){
    opSexo="Feminino";
  }if(sexo[2].checked){
    opSexo="Outros";
  };

  pais = document.getElementById("selPais").value;

  dv = document.getElementById("dvResultado");

  dv.innerHTML = "<h1>Relatorio</h1>" + 
  "nome: <b> " + nome + "</b> <br>" +
  "sexo: <b>" + opSexo + "</b> <br> " +
  "idade: <b>" + idade + "</b> <br> " +
  "País: <b>" + pais + "</b> <br> ";
}
